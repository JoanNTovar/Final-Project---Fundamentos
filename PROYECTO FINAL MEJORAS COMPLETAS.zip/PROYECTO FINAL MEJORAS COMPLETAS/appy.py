from flask import Flask, render_template, request
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io, base64

app = Flask(__name__)

def map_symbols(bits, mod):
    n_bits = {'4PSK': 2, '8PSK': 3, '16PSK': 4, '4QAM': 2, '8QAM': 3, '16QAM': 4}[mod]
    s = []
    all_symbols = []
    M = int(mod[:-3]) if 'PSK' in mod or 'QAM' in mod else 0

    for i in range(M):
        if 'PSK' in mod:
            phase_offset = np.pi / M
            angle = 2 * np.pi * i / M + phase_offset
            all_symbols.append((format(i, f'0{n_bits}b'), np.exp(1j * angle)))
        elif mod == '8QAM':
            phase_offset = np.pi / M
            angle = 2 * np.pi * i / M + phase_offset
            r = np.sqrt(2)
            all_symbols.append((format(i, f'0{n_bits}b'), r * np.exp(1j * angle)))
        elif mod == '4QAM':
            b = format(i, f'0{n_bits}b')
            x = 2 * int(b[0]) - 1
            y = 2 * int(b[1]) - 1
            all_symbols.append((b, x + 1j * y))
        elif mod == '16QAM':
            i_bits = i // 4
            q_bits = i % 4
            gi = i_bits ^ (i_bits >> 1)
            gq = q_bits ^ (q_bits >> 1)
            x = 2 * gi - 3
            y = 2 * gq - 3
            all_symbols.append((format(i, f'0{n_bits}b'), x + 1j * y))

    idx = int(bits, 2)
    s = [sym[1] for sym in all_symbols if sym[0] == bits]

    return np.array(s), all_symbols

def fig_to_base64():
    buf = io.BytesIO()
    plt.tight_layout()
    plt.savefig(buf, format='png', bbox_inches='tight')
    buf.seek(0)
    img = base64.b64encode(buf.read()).decode('ascii')
    buf.close()
    plt.clf()
    return 'data:image/png;base64,' + img

def generate_bit_signal(bits):
    bit_values = [int(b) for b in bits]
    signal = []
    t = []
    for i, b in enumerate(bit_values):
        tt = np.linspace(i, i+1, 100, endpoint=False)
        vv = np.ones_like(tt) * b
        t.extend(tt)
        signal.extend(vv)
    plt.figure(figsize=(8, 2))
    plt.plot(t, signal, drawstyle='steps-post', color='purple')
    plt.ylim(-0.5, 1.5)
    plt.title('Input Bit Signal')
    plt.xlabel('Time')
    plt.ylabel('Bit Value')
    plt.grid(True)
    return fig_to_base64()

def generate_table(symbols, selected_bits):
    table = '<table border="1" cellspacing="0" cellpadding="6" style="margin-top:15px; width:100%; text-align:center;">'
    table += '<tr><th>Bits</th><th>Phase (degrees)</th></tr>'
    for bits, sym in symbols:
        phase = np.degrees(np.angle(sym)) % 360
        if bits == selected_bits:
            table += f'<tr style="background:#d4edda;"><td><strong>{bits}</strong></td><td><strong>{round(phase,2)}°</strong></td></tr>'
        else:
            table += f'<tr><td>{bits}</td><td>{round(phase,2)}°</td></tr>'
    table += '</table>'
    return table

@app.route('/', methods=['GET', 'POST'])
def index():
    vdiag = cdiag = signal = bitsignal = table = rotated_signal = None
    bits = ''
    mod = ''
    rotate = 'no'
    error = ''
    rotation_angle = ''

    if request.method == 'POST':
        bits = request.form.get('bits', '').strip()
        mod = request.form.get('mod')
        rotate = request.form.get('rotate')
        rotation_angle = request.form.get('rotation_angle')

        n_bits_required = {'4PSK': 2, '8PSK': 3, '16PSK': 4, '4QAM': 2, '8QAM': 3, '16QAM': 4}[mod]

        if len(bits) != n_bits_required or not all(b in '01' for b in bits):
            error = f"Invalid bit length for {mod}. You must enter exactly {n_bits_required} bits."
        else:
            s, all_symbols = map_symbols(bits, mod)

            # Vector diagram
            plt.figure(figsize=(4, 4))
            for _, sym in all_symbols:
                plt.quiver(0, 0, sym.real, sym.imag, angles='xy', scale_units='xy', scale=1, color='lightgray')
            plt.quiver(0, 0, s[0].real, s[0].imag, angles='xy', scale_units='xy', scale=1, color='blue')
            plt.axhline(0, color='#ccc'); plt.axvline(0, color='#ccc')
            plt.axis('equal'); plt.grid(True); plt.title('Vector Diagram')
            vdiag = fig_to_base64()

            # Constellation
            plt.figure(figsize=(4, 4))
            for _, sym in all_symbols:
                plt.plot(sym.real, sym.imag, 'o', color='gray')
            plt.plot(s[0].real, s[0].imag, 'o', color='orange', markersize=12)
            plt.grid(True); plt.axis('equal'); plt.title('Constellation Diagram')
            cdiag = fig_to_base64()

            # Output signal
            fs = 200
            t = np.linspace(0, 1, fs, endpoint=False)
            phi = np.angle(s[0])
            sig = np.cos(2 * np.pi * t + phi)
            plt.figure(figsize=(8, 2))
            plt.plot(t, sig)
            plt.grid(True); plt.title('Output Signal'); plt.xlabel('Time'); plt.ylabel('Amplitude')
            signal = fig_to_base64()

            # Bit signal
            bitsignal = generate_bit_signal(bits)

            # Table
            table = generate_table(all_symbols, bits)

            # If rotation selected
            if rotate == 'yes' and rotation_angle in ['+45', '-45']:
                offset = np.pi / 4 if rotation_angle == '+45' else -np.pi / 4
                rotated_phi = phi + offset
                rotated_sig = np.cos(2 * np.pi * t + rotated_phi)
                plt.figure(figsize=(8, 2))
                plt.plot(t, rotated_sig)
                plt.grid(True); plt.title(f'Rotated Output Signal ({rotation_angle}°)')
                plt.xlabel('Time'); plt.ylabel('Amplitude')
                rotated_signal = fig_to_base64()

    return render_template('index.html', vdiag=vdiag, cdiag=cdiag, signal=signal, bitsignal=bitsignal,
                           table=table, rotated_signal=rotated_signal, selected_mod=mod,
                           bits=bits, rotate=rotate, error=error, rotation_angle=rotation_angle)

if __name__ == '__main__':
    app.run(debug=True)
